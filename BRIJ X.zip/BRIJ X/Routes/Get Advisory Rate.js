import express from 'express';
import _, { reduce } from 'lodash';
import axios from 'axios';

const router= express.Router();
router.post('/getAdvisoryRate',(req,res)=>{
    const{
        fromCurrency,
        toCurrency
    }=req.body;

    if(_.isEmpty(fromCurrency))
    {
        res.status(400).send({status: false, message:'Sender Currency Required'});
    }
    else if(_.isEmpty(toCurrency)){
        res.status(400).send({status:false, message:'Receiver Currency Required'});
    }
    else{
        try{
            axios({
                method:'post',
                url: '',
                data: JSON.stringify({
                    from_currency: fromCurrency,
                    to_currency: toCurrency
                })
            })
            .then(value =>{
                res.send(value);
            })
        }
        catch(err){
            console.log(err);
        }
    }
})
export default router;
    
  
    

