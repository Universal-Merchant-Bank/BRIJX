import express from 'express';
import _ from 'lodash';
import axios from 'axios';

const router = express.Router();
router.put('./updateOffer',(req,res)=>{
    const{
           rate,
           amount,
           
    }=req.body

    if(_.isEmpty(rate)){
        res.status(400).send({status: false,message:'Rate Required'});
    }
   
    else if(_.isEmpty(amount)){
        res.status(400).send({status:false, message:'Enter Amount for the swap'})
    
    }
    else
    {
        try{
            axios({
                method:'put',
                url:'',
                data: JSON.stringify({
                    rate: rate,
                    amount: amount
                })
            })
            .then(value =>{
                res.send(value);
            })
        }
        catch(err){
            console.log(err);
        }
    }
})
export default router;