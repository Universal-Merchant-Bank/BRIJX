import express from 'express';
import _, { get } from 'lodash';
import axios from 'axios';

const router= express.Router();
router.get('./clientOffer',(req,res)=>{
    
    
        try{
            axios({
                method:'get',
                url: '',
                data:JSON.stringify({

                })
            })
            .then(value =>{
                res.send(value);
            })
        }
        catch(err){
            console.log(err);
        }
   
})
export default router