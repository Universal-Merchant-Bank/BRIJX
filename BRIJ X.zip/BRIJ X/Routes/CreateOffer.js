import express from 'express';
import _ from 'lodash';
import axios from 'axios';

const router= express.Router();

router.post('/CreateOffer',(req,res)=>{
const {
    fromCurrency,
    toCurrency,
    rate,
    walletId,
    amount,
    expiresAt
    
} = req.body

if(_.isEmpty(fromCurrency)){
    res.status(400).send({status: false, message:'Sender Currency Required'})
}
else if(_.isEmpty(toCurrency)){
    res.status(400).send({status:false, message:'Receiver Currency Required'})
}
else if(_.isEmpty(rate)){
    res.status(400).send({status: false, message:'Rate Required'})
}
else if(_.isEmpty(walletId)){
    res.status(400).send({status: false, message:'Enter Wallet Id'})
}
else if(_.isEmpty(amount)){
    res.status(400).send({status:false, message:'Enter Amount'})
}
else if(_.isEmpty(expiresAt)){
    res.status(400).send({status:false, message:'Deadline Required'})
}
else{
try{
axios({
    method:'post',
    url: '',
    data: JSON.stringify({
        from_currency: fromCurrency,
        to_currency: toCurrency,
        rate: rate,
        wallet_id: walletId,
        amount: amount,
        expires_at: expiresAt

    
    })
}).then(value => {
    res.send(value);
})
}catch(err){
    console.log(err);
}
}

})

export default router;