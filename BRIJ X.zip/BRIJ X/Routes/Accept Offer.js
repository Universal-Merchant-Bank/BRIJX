import express from 'express';
import _ from 'lodash';
import axios from 'axios';

const router = express.Router();
router.post('./acceptOffer',(req,res)=>{
    const{
           offerId,
           amount,
           
    }=req.body

    if(_.isEmpty(offerId)){
        res.status(400).send({status: false,message:'Offer Id Required'});
    }
   
    else if(_.isEmpty(amount)){
        res.status(400).send({status:false, message:'Enter Amount'})
    
    }
    else
    {
        try{
            axios({
                method:'post',
                url:'',
                data: JSON.stringify({
                    offer_id: offerId,
                    amount: amount
                })
            })
            .then(value =>{
                res.send(value);
            })
        }
        catch(err){
            console.log(err);
        }
    }
})
export default router;